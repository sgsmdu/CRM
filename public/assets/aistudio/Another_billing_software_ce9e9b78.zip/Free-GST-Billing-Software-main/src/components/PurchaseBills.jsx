import { useState, useEffect, useMemo, lazy, Suspense } from 'react';
import { ShoppingCart, Plus, Edit3, Trash2, Search, X, Save, Download, Wand2, FileText, Eye } from 'lucide-react';
import HelpButton from './HelpButton';
import { getAllPurchases, savePurchase, deletePurchase, getAllProducts, saveProduct, getProfile } from '../store';
import { formatCurrency, calculateRoundOff, getFYOptions, belongsToProfile, isUnassignedToBusiness, isInterstateSupply, localToday, roundQty } from '../utils';
import TableExport from './TableExport';
import BulkCsvImport from './BulkCsvImport';
import UnassignedBanner from './UnassignedBanner';
import { getPrintSettings } from '../utils/printSettings';
import { toast } from './Toast';
import { confirmAction, promptAction } from './ConfirmModal';

// v1.10.31 — UI-C3: Same accent-color helper as ClientsView so the
// Purchase Bill PDF header rule + totals line pick up the user's brand.
function getAccentRGB() {
  try {
    const ps = getPrintSettings();
    if (ps.userColorsEnabled && ps.pdfAccent) {
      const hex = String(ps.pdfAccent).replace('#', '');
      if (/^[0-9a-f]{6}$/i.test(hex)) {
        return [parseInt(hex.slice(0, 2), 16), parseInt(hex.slice(2, 4), 16), parseInt(hex.slice(4, 6), 16)];
      }
    }
  } catch { /* ignore */ }
  return [30, 64, 175];
}

// v1.10.22 — Purchase-bill OCR modal. Lazy-loaded because tesseract.js is
// ~2MB gzipped; we only pay the download cost when the user actually
// opens the OCR flow.
const BillOCR = lazy(() => import('./BillOCR'));

const PAYMENT_STATUSES = ['Unpaid', 'Paid', 'Partial'];

// v1.10.69 (#71 item 3) - the same three colours the pill used, now shared
// with the dropdown in the records table.
const PAYMENT_STATUS_COLORS = {
  Unpaid:  { bg: 'rgba(245, 158, 11, 0.14)', color: '#f59e0b' },
  Paid:    { bg: 'rgba(5, 150, 105, 0.14)',  color: '#059669' },
  Partial: { bg: 'rgba(139, 92, 246, 0.14)', color: '#8b5cf6' },
};

// cessPercent added in v1.6.8 (P1 #16) — suppliers of tobacco / aerated
// drinks / motor vehicles / coal charge GST + Cess. Without a slot for it,
// we couldn't reclaim ITC on the cess in GSTR-3B Table 4(A).
const emptyItem = { name: '', hsn: '', quantity: 1, rate: 0, taxPercent: 18, cessPercent: 0 };


const emptyForm = {
  date: '', // v1.10.74 - set to localToday() when the form opens
  supplierName: '',
  // v1.10.29 — supplier address for the PDF header. Optional; blank
  // pre-v1.10.29 records fall through gracefully.
  supplierAddress: '',
  supplierGstin: '',
  invoiceNumber: '',
  items: [{ ...emptyItem }],
  paymentStatus: 'Unpaid',
  interstate: false, // true ⇒ supplier charged IGST; false ⇒ CGST + SGST. Routes ITC correctly in GSTR-3B.
  applyRoundOff: false, // off by default — purchase bill totals are usually pre-rounded by the supplier. Users with suppliers that don't pre-round can opt in here.
  note: '',
};

function calcItemTax(item) {
  const amount = (item.quantity || 0) * (item.rate || 0);
  const tax = (amount * (item.taxPercent || 0)) / 100;
  const cess = (amount * (Number(item.cessPercent) || 0)) / 100;
  return { amount, tax, cess, total: amount + tax + cess };
}

function calcPurchaseTotal(items, applyRoundOff = false) {
  const raw = (items || []).reduce((acc, item) => {
    const { amount, tax, cess, total } = calcItemTax(item);
    return {
      taxable: acc.taxable + amount,
      tax: acc.tax + tax,
      cess: acc.cess + cess,
      total: acc.total + total,
    };
  }, { taxable: 0, tax: 0, cess: 0, total: 0 });
  // Round-off is applied to the GRAND total (taxable + tax + cess). Stored
  // as a separate line so GSTR-3B input tax credit reflects the supplier's
  // actual tax amount, not a rounded version.
  const roundOff = applyRoundOff ? calculateRoundOff(raw.total) : 0;
  return { ...raw, roundOff, finalTotal: raw.total + roundOff };
}

// v1.10.6 — audit L4: local copy removed, imported from utils above.

export default function PurchaseBills() {
  const [purchases, setPurchases] = useState([]);
  // v1.10.65 (#58 item 3) — the business these records belong to.
  const [ownerProfile, setOwnerProfile] = useState(null);
  // v1.10.54 (#42) — the Products & Services master, used to seed item
  // suggestions. Loaded on mount alongside purchases.
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [fyFilter, setFyFilter] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState({ ...emptyForm, items: [{ ...emptyItem }] });
  // v1.10.22 — OCR modal state.
  const [showOCR, setShowOCR] = useState(false);
  // v1.10.30 — reported: "add a view only option modal type so can user
  // check the price without downloading the file every time". Holds the
  // purchase being previewed; modal has a Download PDF button inside.
  const [viewPurchase, setViewPurchase] = useState(null);
  const applyOCR = (extracted) => {
    // v1.10.35 — Now consumes the richer payload from BillOCR:
    // extracted.items[] with name/hsn/qty/rate/taxPercent/amount, and
    // extracted.taxBreakdown with cgst/sgst/igst/cess. Falls back to
    // the old single-line-from-grand-total behaviour only if no line
    // items were detected at all.
    setEditingId(null);
    let items;
    if (Array.isArray(extracted.items) && extracted.items.length > 0) {
      // Trust the OCR-extracted line items. Strip the internal match
      // metadata (_matchedProductId etc.) since the purchase form
      // doesn't consume it.
      items = extracted.items.map(it => ({
        name: it.name || '',
        hsn: it.hsn || '',
        quantity: Number(it.quantity) || 1,
        rate: Number(it.rate) || 0,
        taxPercent: Number(it.taxPercent) || 0,
        cessPercent: 0,
      }));
    } else if (extracted.grandTotal > 0) {
      // Legacy fallback — no line items detected, seed a single-row
      // placeholder from the grand total so the user has something to
      // split.
      items = [{ name: 'From OCR — split into real items', hsn: '', quantity: 1, rate: extracted.grandTotal, taxPercent: 0, cessPercent: 0 }];
    } else {
      items = [{ ...emptyItem }];
    }
    // v1.10.74 - IGST on the bill and no CGST means the supplier is in
    // another state, so open the form with Inter-state ticked.
    const tb = extracted.taxBreakdown || {};
    setForm({
      ...emptyForm,
      date: extracted.date || localToday(),
      supplierName: extracted.supplierName || '',
      supplierGstin: extracted.supplierGstin || '',
      invoiceNumber: extracted.invoiceNumber || '',
      items,
      interstate: Number(tb.igst) > 0 && !Number(tb.cgst),
    });
    setShowForm(true);
    const msg = Array.isArray(extracted.items) && extracted.items.length > 0
      ? `OCR loaded ${extracted.items.length} line item${extracted.items.length === 1 ? '' : 's'} — review HSN + tax rates before saving.`
      : 'OCR values loaded — please review, then break the total into line items with correct GST.';
    toast(msg, 'info');
  };

  const fyOptions = getFYOptions();


  // v1.10.65 (#58 item 3) — assign records saved before businesses were kept
  // separate. Never automatic: only the user knows which business an old
  // record belonged to, so guessing would file it into the wrong books.
  const unassignedPurchases = purchases.filter(isUnassignedToBusiness);
  const assignUnassignedPurchases = async () => {
    await Promise.all(unassignedPurchases.map(r => savePurchase({
      ...r,
      ownerGstin: ownerProfile?.gstin || '',
      ownerName: ownerProfile?.businessName || '',
    })));
    loadPurchases();
  };

  const loadPurchases = async () => {
    try {
      const [rows, prof] = await Promise.all([getAllPurchases(), getProfile().catch(() => null)]);
      setOwnerProfile(prof);
      // v1.10.65 (#58 item 3) — show only this business's records. Anything
      // saved before businesses were separated has no owner recorded and is
      // always shown, so nothing disappears from an existing ledger.
      setPurchases((rows || []).filter(r => belongsToProfile(r, prof)));
    } catch {
      toast('Failed to load purchases', 'error');
    }
  };

  // v1.10.54 — reported (#42, @sangwanmail-eng): "Product not show properly
  // in purchase tab". The Products & Services master held Keyboard,
  // motherboard, Mouse, Pen drive — but the purchase item dropdown offered
  // "mouse", "key", "Pen drive": lowercase variants and a half-typed entry
  // from old bills, with two real products missing entirely.
  //
  // Cause: v1.10.50 built the suggestion list purely from what had been
  // TYPED on past purchase bills, and never read the product master. The
  // save path already calls getAllProducts() to update stock, so the data
  // was right there — it just was not being used for suggestions.
  const loadProducts = async () => {
    try {
      setProducts(await getAllProducts());
    } catch {
      // Non-fatal: suggestions fall back to purchase history alone.
    }
  };

  useEffect(() => {
    if (fyOptions[0]) setFyFilter(fyOptions[0].value);
    loadPurchases();
    loadProducts();
  }, []);

  const filtered = purchases.filter(p => {
    if (search.trim()) {
      const q = search.toLowerCase();
      if (!(p.supplierName || '').toLowerCase().includes(q) &&
          !(p.invoiceNumber || '').toLowerCase().includes(q) &&
          !(p.supplierGstin || '').toLowerCase().includes(q)) return false;
    }
    if (fyFilter) {
      const fy = fyOptions.find(f => f.value === fyFilter);
      if (fy && p.date) {
        if (p.date < fy.from || p.date > fy.to) return false;
      }
    }
    return true;
  });

  const totalStats = filtered.reduce((acc, p) => {
    const t = calcPurchaseTotal(p.items, !!p.applyRoundOff);
    return { taxable: acc.taxable + t.taxable, tax: acc.tax + t.tax, total: acc.total + t.finalTotal };
  }, { taxable: 0, tax: 0, total: 0 });

  const openAdd = () => {
    setForm({ ...emptyForm, date: localToday(), items: [{ ...emptyItem }] });
    setEditingId(null);
    setShowForm(true);
  };

  const openEdit = (purchase) => {
    setForm({
      date: purchase.date || '',
      supplierName: purchase.supplierName || '',
      supplierAddress: purchase.supplierAddress || '',
      supplierGstin: purchase.supplierGstin || '',
      invoiceNumber: purchase.invoiceNumber || '',
      items: purchase.items && purchase.items.length > 0 ? purchase.items.map(i => ({ ...i })) : [{ ...emptyItem }],
      paymentStatus: purchase.paymentStatus || 'Unpaid',
      interstate: !!purchase.interstate,
      // Detect round-off from older entries: if roundOff field exists and is
      // non-zero, treat applyRoundOff as on. Older entries without the field
      // just default to off — they won't suddenly change totals on re-save.
      applyRoundOff: !!purchase.applyRoundOff || (typeof purchase.roundOff === 'number' && purchase.roundOff !== 0),
      note: purchase.note || '',
    });
    setEditingId(purchase.id);
    setShowForm(true);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingId(null);
    setForm({ ...emptyForm, items: [{ ...emptyItem }] });
  };

  // v1.10.29 — reported: "option to view as pdf give it that will be
  // better". Generates a simple one-page purchase-bill PDF with header,
  // supplier block, line items table, tax breakdown, and total. Uses
  // jsPDF's built-in text/rect helpers (same as the ledger PDF) so we
  // don't pull autotable and keep the bundle small.
  const viewAsPdf = async (purchase) => {
    try {
      const { jsPDF } = await import('jspdf');
      const t = calcPurchaseTotal(purchase.items, !!purchase.applyRoundOff);
      const doc = new jsPDF({ unit: 'mm', format: 'a4' });
      const marginL = 15, marginR = 195;
      let y = 20;
      const fmt = (n) => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

      doc.setFontSize(18); doc.setFont('helvetica', 'bold');
      doc.text('PURCHASE BILL', marginL, y); y += 8;
      doc.setFontSize(10); doc.setFont('helvetica', 'normal'); doc.setTextColor(100);
      doc.text(`Invoice #: ${purchase.invoiceNumber || '-'}`, marginL, y); y += 5;
      doc.text(`Date: ${purchase.date ? new Date(purchase.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'}`, marginL, y); y += 5;
      doc.text(`Payment: ${purchase.paymentStatus || 'Unpaid'}   ·   ${purchase.interstate ? 'Interstate (IGST)' : 'Intrastate (CGST+SGST)'}`, marginL, y); y += 8;
      doc.setDrawColor(...getAccentRGB()); doc.setLineWidth(0.5);
      doc.line(marginL, y, marginR, y); y += 8;

      doc.setFontSize(11); doc.setFont('helvetica', 'bold'); doc.setTextColor(0);
      doc.text('Supplier', marginL, y); y += 6;
      doc.setFontSize(10); doc.setFont('helvetica', 'normal');
      doc.text(purchase.supplierName || '-', marginL, y); y += 5;
      // v1.10.29 — supplier address (wraps at ~110mm so it doesn't collide
      // with anything on the right side of the header).
      if (purchase.supplierAddress) {
        const wrapped = doc.splitTextToSize(purchase.supplierAddress, 110);
        wrapped.forEach(line => { doc.text(line, marginL, y); y += 5; });
      }
      if (purchase.supplierGstin) { doc.text(`GSTIN: ${purchase.supplierGstin}`, marginL, y); y += 5; }
      y += 4;

      // Items header
      doc.setFontSize(9); doc.setFont('helvetica', 'bold');
      doc.text('#', marginL, y);
      doc.text('Description', marginL + 8, y);
      doc.text('HSN', marginL + 80, y);
      doc.text('Qty', marginL + 100, y, { align: 'right' });
      doc.text('Rate', marginL + 122, y, { align: 'right' });
      doc.text('GST%', marginL + 140, y, { align: 'right' });
      doc.text('Amount', marginR, y, { align: 'right' });
      y += 2; doc.setLineWidth(0.2); doc.line(marginL, y, marginR, y); y += 5;

      doc.setFont('helvetica', 'normal');
      (purchase.items || []).forEach((item, idx) => {
        if (y > 265) { doc.addPage(); y = 20; }
        const lineTotal = (Number(item.quantity) || 0) * (Number(item.rate) || 0);
        const withTax = lineTotal * (1 + (Number(item.taxPercent) || 0) / 100);
        // v1.10.30 — reported: "in purchase bill pdf long names got cut in
        // pdf fix". Prior code used `.slice(0, 40)` which mid-word truncated
        // "4 Copier Paper (Pack of..." → "4 Copier Paper (Pack o". Now we
        // wrap the description into as many lines as needed (70mm column
        // width). The row height grows to fit the wrapped text so nothing
        // clips into the next line.
        const nameCol = 70; // mm — width of description column
        const nameLines = doc.splitTextToSize(String(item.name || '-'), nameCol);
        const rowH = Math.max(6, nameLines.length * 4.5);
        // Page break if this row won't fit.
        if (y + rowH > 275) { doc.addPage(); y = 20; }
        doc.text(String(idx + 1), marginL, y);
        // Description wraps top-aligned.
        nameLines.forEach((line, lineIdx) => {
          doc.text(line, marginL + 8, y + lineIdx * 4.5);
        });
        // Everything else aligns to the top of the row (so it lines up
        // with the first line of the wrapped description).
        doc.text(String(item.hsn || '-'), marginL + 80, y);
        doc.text(String(item.quantity || 0), marginL + 100, y, { align: 'right' });
        doc.text(fmt(item.rate), marginL + 122, y, { align: 'right' });
        doc.text(String(item.taxPercent || 0) + '%', marginL + 140, y, { align: 'right' });
        doc.text(fmt(withTax), marginR, y, { align: 'right' });
        y += rowH;
      });

      // Totals
      y += 4; doc.setDrawColor(...getAccentRGB()); doc.setLineWidth(0.4);
      doc.line(marginL + 100, y, marginR, y); y += 6;
      doc.setFontSize(9); doc.setFont('helvetica', 'normal'); doc.setTextColor(80);
      doc.text('Taxable', marginL + 100, y); doc.text(fmt(t.taxable), marginR, y, { align: 'right' }); y += 5;
      // v1.10.74 - show the tax split instead of one combined line.
      if (purchase.interstate) {
        doc.text('IGST', marginL + 100, y); doc.text(fmt(t.tax), marginR, y, { align: 'right' }); y += 5;
      } else {
        doc.text('CGST', marginL + 100, y); doc.text(fmt(t.tax / 2), marginR, y, { align: 'right' }); y += 5;
        doc.text('SGST', marginL + 100, y); doc.text(fmt(t.tax / 2), marginR, y, { align: 'right' }); y += 5;
      }
      if (t.cess > 0.005) { doc.text('Cess', marginL + 100, y); doc.text(fmt(t.cess), marginR, y, { align: 'right' }); y += 5; }
      if (Math.abs(t.roundOff) > 0.005) { doc.text('Round-off', marginL + 100, y); doc.text((t.roundOff > 0 ? '+' : '') + fmt(t.roundOff), marginR, y, { align: 'right' }); y += 5; }
      y += 2; doc.setDrawColor(0); doc.setLineWidth(0.5); doc.line(marginL + 100, y, marginR, y); y += 6;
      doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor(0);
      doc.text('TOTAL', marginL + 100, y); doc.text(fmt(t.finalTotal), marginR, y, { align: 'right' });

      if (purchase.note) {
        y += 14; doc.setFontSize(9); doc.setFont('helvetica', 'italic'); doc.setTextColor(90);
        doc.text('Note: ' + purchase.note, marginL, y);
      }

      const safeInv = String(purchase.invoiceNumber || 'purchase').replace(/[^A-Za-z0-9._-]/g, '_');
      const filename = `Purchase-${safeInv}-${purchase.date || 'undated'}.pdf`;
      doc.save(filename);
    } catch (err) {
      console.error('Purchase PDF failed:', err);
      toast('Could not generate PDF — see console', 'error');
    }
  };

  const handleSave = async () => {
    if (!form.supplierName.trim()) { toast('Supplier name is required', 'warning'); return; }
    if (!form.invoiceNumber.trim()) { toast('Invoice number is required', 'warning'); return; }
    // v1.10.58 — reported (#47 item 2, @sangwanmail-eng): "Purchase also
    // save without adding any product." Supplier and invoice number were
    // checked, but nothing verified the bill had any line items, so an
    // empty bill saved with a zero total.
    //
    // That is not merely untidy: a purchase bill is the ITC record. A zero
    // bill sits in GSTR-3B reconciliation as a vendor invoice claiming
    // nothing, and the empty rows also feed the stock/product sync on save.
    if (!form.items.some(i => (i.name || '').trim() && (parseFloat(i.quantity) || 0) * (parseFloat(i.rate) || 0) > 0)) {
      toast('Add at least one item with a quantity and rate', 'warning');
      return;
    }
    try {
      const totals = calcPurchaseTotal(form.items, form.applyRoundOff);
      const purchase = {
        ...(editingId ? { id: editingId } : {}),
        date: form.date,
        supplierName: form.supplierName.trim(),
        supplierAddress: (form.supplierAddress || '').trim(),
        supplierGstin: form.supplierGstin.trim(),
        invoiceNumber: form.invoiceNumber.trim(),
        // Which of YOUR businesses bought this. Distinct from supplierGstin
        // directly above, which is who sold it.
        ownerGstin: ownerProfile?.gstin || '',
        ownerName: ownerProfile?.businessName || '',
        items: form.items.map(i => ({
          name: (i.name || '').trim(),
          hsn: (i.hsn || '').trim(),
          quantity: parseFloat(i.quantity) || 0,
          rate: parseFloat(i.rate) || 0,
          taxPercent: parseFloat(i.taxPercent) || 0,
          cessPercent: parseFloat(i.cessPercent) || 0,
        })),
        // totalAmount is the grand total INCLUDING round-off so the table
        // sum and GSTR-3B reconciliation both reflect what the supplier
        // actually charged. roundOff stored separately for audit clarity.
        totalAmount: totals.finalTotal,
        totalTax: totals.tax,
        taxableAmount: totals.taxable,
        applyRoundOff: !!form.applyRoundOff,
        roundOff: totals.roundOff,
        paymentStatus: form.paymentStatus,
        interstate: !!form.interstate,
        note: form.note.trim(),
      };
      await savePurchase(purchase);

      // v1.10.29 — reported: "items added in purchase bill also available
      // for sale means automatically added to the product page too".
      // On save, upsert each line item into Products. Match by trimmed
      // lowercase name to avoid duplicates. For existing products we
      // update purchasePrice (latest cost) but leave sellingPrice alone
      // so we don't accidentally overwrite the user's margin. For new
      // products we seed sellingPrice = purchasePrice as a starting
      // point (user can raise it in Inventory later). Runs in parallel
      // and non-fatal — a single-item failure doesn't block the
      // purchase-bill save.
      // v1.10.31 — Data-F10.1-3: delta-based stock sync. Previously stock
      // was incremented only on FIRST save (create). If the user edited the
      // purchase later — changing qty from 10 → 20, or removing a line, or
      // renaming a line — the product's stock stayed at 10 (F10.1) or a
      // duplicate product was created (F10.3). Now:
      //   • Save (edit path): compute per-line delta from the pre-edit
      //     snapshot; apply that delta to each existing product's stock.
      //   • Save (create path): increment stock by full quantity.
      //   • Rename detection: match by productId first (persisted below),
      //     then by name — a rename with productId keeps the same product.
      try {
        const existingProducts = await getAllProducts();
        const byName = new Map(existingProducts.map(p => [(p.name || '').trim().toLowerCase(), p]));
        const byId = new Map(existingProducts.map(p => [p.id, p]));

        // Pre-edit snapshot: on edit, compute deltas per productId/name.
        const priorLines = editingId
          ? (purchases.find(p => p.id === editingId)?.items || [])
          : [];
        const priorQtyByKey = new Map();
        for (const p of priorLines) {
          const key = p.productId || `name:${(p.name || '').trim().toLowerCase()}`;
          priorQtyByKey.set(key, (priorQtyByKey.get(key) || 0) + (Number(p.quantity) || 0));
        }

        // Batch stock adjustments per product so we don't race on parallel saves.
        const stockDeltaById = new Map();
        const productsToUpsert = new Map();
        const seenPriorKeys = new Set();

        for (const it of purchase.items.filter(x => x.name)) {
          const qty = Number(it.quantity) || 0;
          // Match order: productId (persisted below) → name (case-insensitive).
          let existing = it.productId ? byId.get(it.productId) : null;
          if (!existing) {
            const key = it.name.trim().toLowerCase();
            existing = byName.get(key);
          }
          if (existing) {
            // Delta = current qty − prior qty (for this product).
            const priorKey = it.productId
              ? it.productId
              : `name:${(it.name || '').trim().toLowerCase()}`;
            const priorQty = priorQtyByKey.get(priorKey) || 0;
            seenPriorKeys.add(priorKey);
            const delta = qty - priorQty; // may be negative (line reduced) or zero (unchanged)
            stockDeltaById.set(existing.id, (stockDeltaById.get(existing.id) || 0) + delta);
            productsToUpsert.set(existing.id, {
              ...existing,
              purchasePrice: it.rate,
              hsn: existing.hsn || it.hsn,
              taxPercent: existing.taxPercent || it.taxPercent,
              cessPercent: existing.cessPercent || it.cessPercent || 0,
              // stock filled after we sum all deltas for this product.
              _placeholderId: existing.id,
            });
          } else {
            // New product — seed stock with the line qty (all its lines: two
            // lines of the same new item used to keep only the last one's).
            const newKey = `__new__::${it.name.trim().toLowerCase()}`;
            const seeded = Number(productsToUpsert.get(newKey)?.stock) || 0;
            productsToUpsert.set(newKey, {
              name: it.name.trim(),
              hsn: it.hsn || '',
              purchasePrice: it.rate,
              sellingPrice: it.rate,
              rate: it.rate,
              taxPercent: it.taxPercent || 0,
              cessPercent: it.cessPercent || 0,
              unit: 'Nos',
              stock: roundQty(seeded + qty),
              description: '',
            });
          }
        }

        // Rows removed while editing: their stock was added when the bill was
        // first saved, so take it back out (it used to stay in stock forever).
        for (const [key, priorQty] of priorQtyByKey) {
          if (seenPriorKeys.has(key)) continue;
          const gone = key.startsWith('name:') ? byName.get(key.slice(5)) : byId.get(key);
          if (!gone) continue;
          stockDeltaById.set(gone.id, (stockDeltaById.get(gone.id) || 0) - priorQty);
          if (!productsToUpsert.has(gone.id)) productsToUpsert.set(gone.id, { ...gone, _placeholderId: gone.id });
        }

        // Apply deltas + write.
        const upserts = [];
        for (const [key, prod] of productsToUpsert) {
          if (prod._placeholderId) {
            const existing = byId.get(prod._placeholderId);
            const delta = stockDeltaById.get(prod._placeholderId) || 0;
            // Not clamped at 0: sales may take stock below zero, and clamping
            // here made a purchase edit and its undo leave different stock
            // (stock 2, reduce a purchase by 5 -> 0, put it back -> 5).
            const newStock = roundQty((Number(existing.stock) || 0) + delta);
            upserts.push(saveProduct({ ...prod, stock: newStock, _placeholderId: undefined }));
          } else {
            upserts.push(saveProduct(prod));
          }
        }
        await Promise.all(upserts);
        toast(editingId ? 'Purchase updated' : 'Purchase added — items synced to Products', 'success');
      } catch (e) {
        console.warn('Products auto-sync from purchase failed (non-fatal):', e);
        toast('Purchase saved, but updating stock in Products failed - check them there', 'warning');
      }

      closeForm();
      loadPurchases();
      // v1.10.54 — saving a bill upserts its items into the product master
      // (that is what the toast above means by "synced to Products"), so
      // refresh it too. Otherwise a brand-new item would not appear in the
      // suggestions until the page was reloaded.
      loadProducts();
    } catch {
      toast('Failed to save purchase', 'error');
    }
  };

  // v1.10.69 (#71 item 3) - change the payment status straight from the list.
  // Saves the whole record back, so nothing else about the bill is disturbed;
  // the list is reloaded afterwards so the supplier-payable totals follow.
  const changePaymentStatus = async (purchase, paymentStatus) => {
    if ((purchase.paymentStatus || 'Unpaid') === paymentStatus) return;
    try {
      await savePurchase({ ...purchase, paymentStatus });
      toast(`Marked ${paymentStatus.toLowerCase()}`, 'success');
      loadPurchases();
    } catch {
      toast('Could not change the status', 'error');
    }
  };

  // Take a deleted bill's quantities back out of product stock.
  // Matches products the same way saving does: productId, then name.
  const revertPurchaseStock = async (bill) => {
    const lines = (bill?.items || []).filter(it => it.name && Number(it.quantity) > 0);
    if (!lines.length) return;
    const products = await getAllProducts();
    const byName = new Map(products.map(p => [(p.name || '').trim().toLowerCase(), p]));
    const byId = new Map(products.map(p => [p.id, p]));
    const minus = new Map();
    for (const it of lines) {
      const prod = (it.productId && byId.get(it.productId)) || byName.get(it.name.trim().toLowerCase());
      if (prod) minus.set(prod.id, (minus.get(prod.id) || 0) + Number(it.quantity));
    }
    await Promise.all([...minus].map(([pid, qty]) => {
      const prod = byId.get(pid);
      return saveProduct({ ...prod, stock: roundQty((Number(prod.stock) || 0) - qty) });
    }));
  };

  const handleDelete = async (id) => {
    if (await confirmAction({
      title: 'Delete this purchase bill?',
      message: 'Stock levels for the products in this bill will be reverted. Any GST ITC already claimed against this bill in past returns stays as filed.',
      confirmLabel: 'Delete',
      tone: 'danger',
    })) {
      try {
        const bill = purchases.find(p => p.id === id);
        await deletePurchase(id);
        // The confirm above promises this: the bill's quantities were added to
        // stock when it was saved, so deleting it takes them back out.
        let stockOk = true;
        try { await revertPurchaseStock(bill); } catch (e) { stockOk = false; console.warn('Stock revert failed', e); }
        toast(stockOk ? 'Purchase deleted' : 'Purchase deleted, but its stock could not be taken out of Products', stockOk ? 'success' : 'warning');
        loadPurchases();
      } catch {
        toast('Failed to delete', 'error');
      }
    }
  };

  // v1.10.50 — reported (#39, @sangwanmail-eng): "In add purchase option
  // previous added supplier and item not shown. So all details need to be
  // fill again, like supplier name, gst number, address, item name etc".
  //
  // Purchase bills store supplier details INLINE (supplierName /
  // supplierGstin / supplierAddress) rather than against a supplier master
  // record, so unlike the invoice side — which has saved clients and
  // product suggestions — there was nothing to recall and every bill meant
  // retyping the GSTIN by hand. For someone entering a stack of bills from
  // the same three or four vendors that is the bulk of the typing, and a
  // mistyped GSTIN quietly breaks ITC reconciliation in GSTR-3B.
  //
  // Rather than introduce a supplier master (a migration, and a second
  // place for the same data to drift), derive the history from the bills
  // already loaded in `purchases`. Newest first, so the most recent
  // spelling of a supplier wins.
  const supplierHistory = useMemo(() => {
    const seen = new Map();
    for (const p of purchases) {
      const name = (p.supplierName || '').trim();
      if (!name) continue;
      const key = name.toLowerCase();
      // First wins: `purchases` arrives newest-first, so this keeps the
      // most recent details for a supplier rather than the oldest.
      if (!seen.has(key)) {
        seen.set(key, {
          name,
          gstin: (p.supplierGstin || '').trim(),
          address: (p.supplierAddress || '').trim(),
          interstate: !!p.interstate,
        });
      }
    }
    return [...seen.values()];
  }, [purchases]);

  // v1.10.54 (#42) — suggestions come from the product master FIRST, then
  // anything else that has been typed on a past bill.
  //
  // Order matters: the master is inserted first and the map is first-wins,
  // so "Mouse" from Products beats a stray "mouse" typed on an old bill.
  // Deduping is case-insensitive for the same reason — the user should see
  // one entry with the spelling they curated, not two differing in case.
  //
  // Purchase-only names are still kept. A one-off item bought once and
  // never added to the catalogue is legitimate history, and there is no
  // reliable way to tell that apart from an old typo — so both stay, and
  // the user decides.
  const itemHistory = useMemo(() => {
    const seen = new Map();

    for (const pr of products) {
      const name = (pr.name || '').trim();
      if (!name) continue;
      seen.set(name.toLowerCase(), {
        name,
        hsn: (pr.hsn || '').trim(),
        // purchasePrice is what we PAY a supplier; `rate`/sellingPrice is
        // what we charge a customer. On a purchase bill the former is the
        // sensible prefill.
        rate: Number(pr.purchasePrice) || Number(pr.rate) || 0,
        taxPercent: Number(pr.taxPercent) || 0,
        cessPercent: Number(pr.cessPercent) || 0,
      });
    }

    for (const p of purchases) {
      for (const it of (p.items || [])) {
        const name = (it.name || '').trim();
        if (!name) continue;
        const key = name.toLowerCase();
        if (!seen.has(key)) {
          seen.set(key, {
            name,
            hsn: (it.hsn || '').trim(),
            rate: Number(it.rate) || 0,
            taxPercent: Number(it.taxPercent) || 0,
            cessPercent: Number(it.cessPercent) || 0,
          });
        }
      }
    }

    return [...seen.values()].sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
  }, [products, purchases]);

  const updateField = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  // v1.10.76 (#82) - a full supplier GSTIN sets "Inter-state" from the two
  // states, the way sales invoices already work it out. The box stays
  // editable for the rare exception.
  const updateSupplierGstin = (value) => setForm(prev => {
    const interstate = isInterstateSupply(value, ownerProfile);
    return interstate === null ? { ...prev, supplierGstin: value } : { ...prev, supplierGstin: value, interstate };
  });

  // Typing or picking a known supplier fills in the rest of their details.
  //
  // Deliberately only fills fields the user has left BLANK. Overwriting
  // whatever they already typed would be worse than not helping — someone
  // correcting a supplier's new GSTIN would watch the old one reappear as
  // they finished typing the name.
  const updateSupplierName = (value) => {
    const match = supplierHistory.find(s => s.name.toLowerCase() === value.trim().toLowerCase());
    setForm(prev => {
      const next = { ...prev, supplierName: value };
      if (match) {
        // v1.10.55 (#43) — same re-selection bug as the item rows, and worse
        // here: switching supplier used to leave the PREVIOUS supplier's
        // GSTIN in place, so the bill was filed against the wrong taxpayer
        // and ITC reconciliation broke. See isOursToReplace above.
        const last = prev._autoSupplier || {};
        if (isOursToReplace(prev.supplierGstin, last.gstin)) next.supplierGstin = match.gstin;
        if (isOursToReplace(prev.supplierAddress, last.address)) next.supplierAddress = match.address;
        // Interstate drives CGST+SGST vs IGST, so recall it too — it is a
        // property of where the supplier is, and getting it wrong routes
        // ITC to the wrong GSTR-3B column.
        next.interstate = match.interstate;
        next._autoSupplier = { gstin: match.gstin, address: match.address };
      }
      return next;
    });
  };

  // Same idea for line items: recall HSN, rate and tax rates from the last
  // time this item was purchased. Rate is filled only when still 0 so a
  // price change the user has already typed is never clobbered.
  // v1.10.55 — reported (#43, @sangwanmail-eng): "when we select item all
  // details fetch ok. But when we change item in same field details not
  // change."
  //
  // v1.10.50 filled a field only when it was BLANK, to avoid overwriting
  // something the user had typed. That protected typed input but broke
  // re-selection: pick "Pen drive" (HSN fills to `s`), then change the same
  // row to "Mouse" — HSN is no longer blank, so it stayed on Pen drive's
  // value. The bill then carried the wrong HSN and the wrong rate, silently.
  //
  // The flaw was treating "field is non-empty" as "user typed this". We now
  // record what WE auto-filled on the row (`_auto`, transient — the save
  // path whitelists fields, so it never persists). A field is ours to
  // replace when it is empty or still holds exactly what we last put there;
  // once the user edits it, it stops matching and we leave it alone.
  //
  // So: re-selecting updates the details, and a hand-typed correction still
  // survives — both, rather than one at the cost of the other.
  const isOursToReplace = (current, lastAuto) => {
    const cur = current === undefined || current === null ? '' : String(current).trim();
    if (cur === '' || cur === '0') return true;              // never filled, or still zero
    if (lastAuto === undefined || lastAuto === null) return false;
    return cur === String(lastAuto).trim();                  // untouched since we filled it
  };

  const updateItemName = (index, value) => {
    const match = itemHistory.find(i => i.name.toLowerCase() === value.trim().toLowerCase());
    setForm(prev => {
      const items = [...prev.items];
      const cur = { ...items[index], name: value };
      if (match) {
        const last = cur._auto || {};
        if (isOursToReplace(cur.hsn, last.hsn)) cur.hsn = match.hsn;
        if (isOursToReplace(cur.rate, last.rate)) cur.rate = match.rate;
        if (isOursToReplace(cur.taxPercent, last.taxPercent)) cur.taxPercent = match.taxPercent;
        if (isOursToReplace(cur.cessPercent, last.cessPercent)) cur.cessPercent = match.cessPercent;
        // Remember exactly what we just wrote, so the next re-selection can
        // tell our values apart from the user's.
        cur._auto = {
          hsn: match.hsn,
          rate: match.rate,
          taxPercent: match.taxPercent,
          cessPercent: match.cessPercent,
        };
      }
      items[index] = cur;
      return { ...prev, items };
    });
  };

  const updateItem = (index, field, value) => {
    setForm(prev => {
      const items = [...prev.items];
      items[index] = { ...items[index], [field]: value };
      return { ...prev, items };
    });
  };

  const addItem = () => {
    // Tag the new row so we can focus its first input after React renders.
    // Tab → Enter on the Add Item button now keeps the user in keyboard
    // flow instead of forcing a mouse click on the empty row.
    const focusKey = 'new-' + Date.now();
    setForm(prev => ({ ...prev, items: [...prev.items, { ...emptyItem, _focusKey: focusKey }] }));
    requestAnimationFrame(() => {
      const el = document.querySelector(`[data-focus-key="${focusKey}"] input.form-input`);
      if (el) el.focus();
    });
  };

  const removeItem = (index) => {
    if (form.items.length <= 1) return;
    setForm(prev => ({ ...prev, items: prev.items.filter((_, i) => i !== index) }));
  };

  // v1.10.77 (#85) - the purchase register as CSV, Excel or Print / PDF, with
  // a total row. v1.10.74 columns kept: Cess and Inter-state; Tax never
  // included cess.
  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
  const registerRows = (() => {
    if (!filtered.length) return [];
    const sum = { taxable: 0, tax: 0, cess: 0, roundOff: 0, finalTotal: 0 };
    const rows = [...filtered].sort((x, y) => String(x.date || '').localeCompare(String(y.date || ''))).map(p => {
      const t = calcPurchaseTotal(p.items, !!p.applyRoundOff);
      for (const k of Object.keys(sum)) sum[k] += Number(t[k]) || 0;
      return [p.date || '', p.supplierName || '', p.supplierGstin || '', p.invoiceNumber || '', r2(t.taxable), r2(t.tax), r2(t.cess),
        p.interstate ? 'Y' : 'N', r2(t.roundOff), r2(t.finalTotal), p.paymentStatus || '', p.note || ''];
    });
    return [...rows, ['Total', '', '', '', r2(sum.taxable), r2(sum.tax), r2(sum.cess), '', r2(sum.roundOff), r2(sum.finalTotal), '', '']];
  })();

  const formTotals = calcPurchaseTotal(form.items, form.applyRoundOff);

  return (
    <div className="dashboard-container">
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div>
            <h1 className="page-title">Purchase Bills</h1>
            <p className="page-subtitle">Track supplier invoices for ITC claims in GSTR-3B</p>
          </div>
          <HelpButton title="Purchase Bills — how to use" doc="purchases">
            <ul style={{ paddingLeft: '1.1rem', margin: 0 }}>
              <li><strong>Add Purchase</strong> — record every supplier tax invoice you receive. The GST paid becomes your ITC (input tax credit) in GSTR-3B.</li>
              <li><strong>Import from image (OCR)</strong> — snap the supplier's invoice with your phone. The app reads the supplier, GSTIN, invoice number, date, total and the item lines it can find, all on your computer. Check every field before saving.</li>
              <li><strong>Interstate toggle</strong> — flip ON when the supplier is in a different state (they charged IGST) so ITC routes correctly.</li>
              <li><strong>Payment status</strong> — Unpaid / Partial / Paid drives the "amount payable to suppliers" report.</li>
              <li><strong>Print / PDF</strong>, <strong>Excel</strong> and <strong>CSV</strong> above the list: the purchase register with totals, for your CA at return time.</li>
            </ul>
          </HelpButton>
        </div>
        <div className="flex gap-2">
          <button className="btn btn-secondary" onClick={() => setShowOCR(true)} title="Extract fields from a bill photo/scan">
            <Wand2 size={16} /> Import from image (OCR)
          </button>
          <BulkCsvImport kind="purchase" onDone={() => { loadPurchases(); loadProducts(); }} />
          <button className="btn btn-primary" onClick={openAdd}><Plus size={18} /> Add Purchase</button>
        </div>
      </div>

      {/* v1.10.22 — Bill OCR modal (tesseract.js, lazy-loaded). */}
      {showOCR && (
        <Suspense fallback={<div className="modal-overlay"><div className="modal-content" style={{ maxWidth: 320, textAlign: 'center' }}>Loading OCR…</div></div>}>
          <BillOCR onClose={() => setShowOCR(false)} onExtracted={applyOCR} />
        </Suspense>
      )}

      {/* v1.10.30 — Purchase view modal (quick check, no download). */}
      {viewPurchase && (() => {
        const p = viewPurchase;
        const t = calcPurchaseTotal(p.items, !!p.applyRoundOff);
        return (
          <div className="modal-overlay" onClick={() => setViewPurchase(null)}>
            <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: 720 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                <h3 className="section-title" style={{ margin: 0 }}>Purchase Bill · {p.invoiceNumber || '—'}</h3>
                <button className="icon-btn" onClick={() => setViewPurchase(null)} title="Close"><X size={18} /></button>
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>
                {p.date ? new Date(p.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : ''} · {p.paymentStatus || 'Unpaid'} · {p.interstate ? 'Interstate (IGST)' : 'Intrastate (CGST+SGST)'}
              </div>
              {/* Supplier block */}
              <div style={{ background: 'var(--bg-secondary)', padding: '0.75rem 1rem', borderRadius: 6, marginBottom: '1rem' }}>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: 4 }}>Supplier</div>
                <div style={{ fontWeight: 600 }}>{p.supplierName || '—'}</div>
                {p.supplierAddress && <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>{p.supplierAddress}</div>}
                {p.supplierGstin && <div style={{ fontSize: '0.82rem' }}>GSTIN: <strong>{p.supplierGstin}</strong></div>}
              </div>
              {/* Line items */}
              <div style={{ overflowX: 'auto', maxHeight: 260, overflowY: 'auto', border: '1px solid var(--border)', borderRadius: 6, marginBottom: '1rem' }}>
                <table className="data-table" style={{ fontSize: '0.82rem', width: '100%', minWidth: 500 }}>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Description</th>
                      <th>HSN</th>
                      <th style={{ textAlign: 'right' }}>Qty</th>
                      <th style={{ textAlign: 'right' }}>Rate</th>
                      <th style={{ textAlign: 'right' }}>GST%</th>
                      <th style={{ textAlign: 'right' }}>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(p.items || []).map((it, idx) => {
                      const line = (Number(it.quantity) || 0) * (Number(it.rate) || 0);
                      const withTax = line * (1 + (Number(it.taxPercent) || 0) / 100);
                      return (
                        <tr key={idx}>
                          <td style={{ color: 'var(--text-muted)' }}>{idx + 1}</td>
                          <td style={{ whiteSpace: 'normal', wordBreak: 'break-word' }}>{it.name || '—'}</td>
                          <td style={{ color: 'var(--text-muted)' }}>{it.hsn || '—'}</td>
                          <td style={{ textAlign: 'right' }}>{it.quantity || 0}</td>
                          <td style={{ textAlign: 'right' }}>{formatCurrency(it.rate || 0)}</td>
                          <td style={{ textAlign: 'right' }}>{it.taxPercent || 0}%</td>
                          <td style={{ textAlign: 'right', fontWeight: 600 }}>{formatCurrency(withTax)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {/* Totals */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: '0.35rem 1rem', fontSize: '0.9rem', maxWidth: 320, marginLeft: 'auto' }}>
                <span style={{ color: 'var(--text-muted)' }}>Taxable</span>
                <span style={{ textAlign: 'right' }}>{formatCurrency(t.taxable)}</span>
                {/* v1.10.74 - tax split: IGST, or CGST + SGST half each. */}
                {p.interstate ? (
                  <><span style={{ color: 'var(--text-muted)' }}>IGST</span><span style={{ textAlign: 'right' }}>{formatCurrency(t.tax)}</span></>
                ) : (
                  <>
                    <span style={{ color: 'var(--text-muted)' }}>CGST</span><span style={{ textAlign: 'right' }}>{formatCurrency(t.tax / 2)}</span>
                    <span style={{ color: 'var(--text-muted)' }}>SGST</span><span style={{ textAlign: 'right' }}>{formatCurrency(t.tax / 2)}</span>
                  </>
                )}
                {t.cess > 0.005 && <><span style={{ color: 'var(--text-muted)' }}>Cess</span><span style={{ textAlign: 'right' }}>{formatCurrency(t.cess)}</span></>}
                {Math.abs(t.roundOff) > 0.005 && <><span style={{ color: 'var(--text-muted)', fontStyle: 'italic' }}>Round-off</span><span style={{ textAlign: 'right', fontStyle: 'italic' }}>{(t.roundOff > 0 ? '+' : '') + formatCurrency(t.roundOff)}</span></>}
                <span style={{ borderTop: '2px solid var(--text)', paddingTop: 6, fontWeight: 700 }}>TOTAL</span>
                {/* v1.10.34 — was hardcoded color:'#0f172a' (slate-900) which
                    disappeared against the dark card background. Reported
                    with screenshot showing invisible total on Purchase Bill
                    view modal. Now uses --text so it flips with theme. */}
                <span style={{ borderTop: '2px solid var(--text)', paddingTop: 6, textAlign: 'right', fontWeight: 700, fontSize: '1.05rem', color: 'var(--text)' }}>{formatCurrency(t.finalTotal)}</span>
              </div>
              {p.note && <p style={{ fontSize: '0.82rem', fontStyle: 'italic', color: 'var(--text-muted)', marginTop: '1rem' }}>Note: {p.note}</p>}
              {/* Action bar */}
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', marginTop: '1rem', paddingTop: '1rem', borderTop: '1px solid var(--border)' }}>
                <button className="btn btn-secondary" onClick={() => setViewPurchase(null)}>Close</button>
                <button className="btn btn-secondary" onClick={() => { openEdit(p); setViewPurchase(null); }}><Edit3 size={14} /> Edit</button>
                <button className="btn btn-primary" onClick={() => viewAsPdf(p)}><Download size={14} /> Download PDF</button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Stats */}
      <UnassignedBanner
        count={unassignedPurchases.length}
        businessName={ownerProfile?.businessName}
        noun="purchase bill"
        onAssign={assignUnassignedPurchases}
      />

      <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
        <div className="stat-card">
          <div className="stat-icon stat-icon-purple"><ShoppingCart size={22} /></div>
          <div><p className="stat-label">Total Purchases</p><h2 className="stat-value stat-value-purple">{formatCurrency(totalStats.total)}</h2></div>
        </div>
        <div className="stat-card">
          <div className="stat-icon stat-icon-green"><ShoppingCart size={22} /></div>
          <div><p className="stat-label">GST (ITC Eligible)</p><h2 className="stat-value stat-value-green">{formatCurrency(totalStats.tax)}</h2></div>
        </div>
        <div className="stat-card">
          <div className="stat-icon stat-icon-blue"><ShoppingCart size={22} /></div>
          <div><p className="stat-label">Entries</p><h2 className="stat-value">{filtered.length}</h2></div>
        </div>
      </div>

      {/* Filters */}
      <div className="glass-panel p-4 mb-6">
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', alignItems: 'center' }}>
          <div className="search-box" style={{ maxWidth: '300px' }}>
            <Search size={16} className="search-icon" />
            <input type="text" placeholder="Search supplier, invoice..." value={search}
              onChange={e => setSearch(e.target.value)} className="search-input" />
          </div>
          <select className="filter-select" value={fyFilter} onChange={e => setFyFilter(e.target.value)}>
            {/* v1.10.74 - '' already means no FY filter below. */}
            <option value="">All years</option>
            {fyOptions.map(fy => <option key={fy.value} value={fy.value}>{fy.label}</option>)}
          </select>
          {search && (
            <button className="icon-btn icon-btn-red" onClick={() => setSearch('')} title="Clear search" aria-label="Clear search"><X size={15} /></button>
          )}
        </div>
      </div>

      {/* Add/Edit Modal */}
      {showForm && (
        <div className="modal-overlay" onClick={closeForm}>
          <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '720px' }}>
            <h3 className="section-title">{editingId ? 'Edit Purchase Bill' : 'Add Purchase Bill'}</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="form-group">
                <label className="form-label">Date *</label>
                <input type="date" className="form-input" value={form.date} onChange={e => updateField('date', e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Payment Status</label>
                <select className="form-input" value={form.paymentStatus} onChange={e => updateField('paymentStatus', e.target.value)}>
                  {PAYMENT_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Supplier Name *</label>
                {/* v1.10.50 (#39) — recall previously used suppliers. A native
                    <datalist> rather than a custom dropdown: it is keyboard
                    accessible for free, does not trap focus, and degrades to a
                    plain text field, which matters because a supplier not yet
                    in the history must still be typeable. */}
                <input type="text" className="form-input" value={form.supplierName}
                  list="fgsb-supplier-history" autoComplete="off"
                  onChange={e => updateSupplierName(e.target.value)}
                  placeholder={supplierHistory.length ? 'Type or pick a previous supplier' : 'Vendor / Supplier name'} />
                {/* v1.10.52 (#40) — value ONLY, never child text or a label
                    attribute. Browsers disagree about which one they show:
                    Chrome lists the value with the label as secondary text,
                    Firefox shows the label INSTEAD of the value. v1.10.50 put
                    the GSTIN in the child text as a hint, so Firefox users got
                    a list of GST numbers where supplier names should be.
                    The GSTIN is auto-filled on selection anyway, so the hint
                    bought nothing and cost the actual name. */}
                <datalist id="fgsb-supplier-history">
                  {supplierHistory.map(s => <option key={s.name} value={s.name} />)}
                </datalist>
              </div>
              <div className="form-group">
                <label className="form-label">Supplier GSTIN</label>
                <input type="text" className="form-input" value={form.supplierGstin}
                  onChange={e => updateSupplierGstin(e.target.value)} placeholder="15-digit GSTIN" maxLength={15} />
              </div>
              {/* v1.10.29 — Supplier address for the PDF. Optional; full width row. */}
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Supplier Address (optional)</label>
                <input type="text" className="form-input" value={form.supplierAddress || ''}
                  onChange={e => updateField('supplierAddress', e.target.value)}
                  placeholder="Street, City, State — printed on the Purchase Bill PDF" />
              </div>
              <div className="form-group">
                <label className="form-label">Invoice Number *</label>
                <input type="text" className="form-input" value={form.invoiceNumber}
                  onChange={e => updateField('invoiceNumber', e.target.value)} placeholder="Supplier invoice no." />
              </div>
              <div className="form-group">
                <label className="form-label">Note (optional)</label>
                <input type="text" className="form-input" value={form.note}
                  onChange={e => updateField('note', e.target.value)} placeholder="Any note..." />
              </div>
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.82rem', cursor: 'pointer' }}>
                  <input type="checkbox" checked={!!form.interstate}
                    onChange={e => updateField('interstate', e.target.checked)}
                    style={{ width: 16, height: 16, accentColor: 'var(--primary)' }} />
                  <span>
                    <strong>Inter-state purchase</strong> — supplier charged IGST (different state)
                    <span style={{ color: '#94a3b8', fontSize: '0.72rem', display: 'block' }}>
                      Routes ITC to IGST in GSTR-3B instead of CGST + SGST. Tip: first 2 digits of supplier GSTIN = their state code.
                    </span>
                  </span>
                </label>
              </div>
            </div>

            {/* Items */}
            <h4 style={{ marginTop: '1rem', marginBottom: '0.5rem', fontWeight: 600, fontSize: '0.9rem' }}>Items</h4>
            {/* Rendered once for all rows — a <datalist> is referenced by id,
                so duplicating it per row would only bloat the DOM. */}
            {/* Same rule as the supplier list above — value only. */}
            <datalist id="fgsb-item-history">
              {itemHistory.map(i => <option key={i.name} value={i.name} />)}
            </datalist>
            {form.items.map((item, idx) => (
              <div key={idx} data-focus-key={item._focusKey} style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem', flexWrap: 'wrap', alignItems: 'flex-end' }}>
                <div className="form-group" style={{ flex: 2, margin: 0 }}>
                  {idx === 0 && <label className="form-label">Name</label>}
                  {/* v1.10.50 (#39) — recall previously purchased items along
                      with their HSN, rate and tax rates. One shared datalist
                      serves every row; the browser scopes suggestions to the
                      focused input. */}
                  <input type="text" className="form-input" value={item.name}
                    list="fgsb-item-history" autoComplete="off"
                    onChange={e => updateItemName(idx, e.target.value)}
                    placeholder={itemHistory.length ? 'Type or pick a previous item' : 'Item name'} />
                </div>
                <div className="form-group" style={{ flex: 1, margin: 0 }}>
                  {idx === 0 && <label className="form-label">HSN</label>}
                  <input type="text" className="form-input" value={item.hsn}
                    onChange={e => updateItem(idx, 'hsn', e.target.value)} placeholder="HSN" />
                </div>
                <div className="form-group" style={{ flex: 0.7, margin: 0 }}>
                  {idx === 0 && <label className="form-label">Qty</label>}
                  {/* v1.6.8 (P2 #30): decimal quantity for 2.5 kg / 0.5 hr / etc. */}
                  {/* v1.10.69 - requested (#71 item 2, @sangwanmail-eng): the
                      number fields here now select their contents on focus, as
                      the invoice screen has since v1.10.67. Without it, typing
                      into a field showing 0 gave you 018 rather than 18. */}
                  <input type="number" className="form-input" value={item.quantity} min="0" step="any"
                    onFocus={e => e.target.select()}
                    onChange={e => updateItem(idx, 'quantity', e.target.value)} />
                </div>
                <div className="form-group" style={{ flex: 1, margin: 0 }}>
                  {idx === 0 && <label className="form-label">Rate</label>}
                  <input type="number" className="form-input" value={item.rate} min="0" step="any"
                    onFocus={e => e.target.select()}
                    onChange={e => updateItem(idx, 'rate', e.target.value)} />
                </div>
                <div className="form-group" style={{ flex: 0.75, margin: 0 }}>
                  {idx === 0 && <label className="form-label">Tax %</label>}
                  {/* v1.6.8 (P2 #29): "Other…" for jeweller 3% / diamond 0.25% /
                       agriculture 0.1% and any bespoke rate. */}
                  <select className="form-input" value={
                    ['0','0.1','0.25','3','5','12','18','28','40'].includes(String(item.taxPercent)) ? String(item.taxPercent) : '__custom__'
                  } onChange={async e => {
                    if (e.target.value === '__custom__') {
                      const v = await promptAction({
                        title: 'Custom tax rate',
                        message: 'Enter a GST rate between 0% and 100% (up to 2 decimals).',
                        defaultValue: String(item.taxPercent || 0),
                        placeholder: 'e.g. 7.5',
                        inputType: 'number',
                        confirmLabel: 'Apply rate',
                      });
                      const n = parseFloat(v);
                      if (Number.isFinite(n) && n >= 0 && n <= 100) updateItem(idx, 'taxPercent', n);
                    } else {
                      updateItem(idx, 'taxPercent', e.target.value);
                    }
                  }}>
                    <option value="0">0%</option>
                    <option value="0.1">0.1%</option>
                    <option value="0.25">0.25%</option>
                    <option value="3">3%</option>
                    <option value="5">5%</option>
                    <option value="12">12%</option>
                    <option value="18">18%</option>
                    <option value="28">28%</option>
                    <option value="40">40%</option>
                    <option value="__custom__">Other…{['0','0.1','0.25','3','5','12','18','28','40'].includes(String(item.taxPercent)) ? '' : ` (${item.taxPercent}%)`}</option>
                  </select>
                </div>
                <div className="form-group" style={{ flex: 0.7, margin: 0 }}>
                  {idx === 0 && <label className="form-label" title="Compensation Cess — for tobacco, aerated, motor vehicles, coal, etc.">Cess %</label>}
                  <input type="number" className="form-input" value={item.cessPercent ?? 0} min="0" step="any"
                    onFocus={e => e.target.select()}
                    onChange={e => updateItem(idx, 'cessPercent', e.target.value)} />
                </div>
                <div style={{ flex: '0 0 auto', marginBottom: idx === 0 ? 0 : 0 }}>
                  {form.items.length > 1 && (
                    <button className="icon-btn icon-btn-red" onClick={() => removeItem(idx)} title="Remove"><Trash2 size={15} /></button>
                  )}
                </div>
              </div>
            ))}
            <button className="btn btn-secondary" style={{ fontSize: '0.8rem', padding: '0.35rem 0.75rem', marginTop: '0.25rem' }}
              onClick={addItem}><Plus size={14} /> Add Item</button>

            <div style={{ marginTop: '1rem', padding: '0.75rem', background: 'var(--bg-secondary)', borderRadius: 8, fontSize: '0.85rem' }}>
              <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
                <span>Taxable: <strong>{formatCurrency(formTotals.taxable)}</strong></span>
                <span>Tax: <strong>{formatCurrency(formTotals.tax)}</strong></span>
                {formTotals.cess > 0 && (
                  <span>Cess: <strong>{formatCurrency(formTotals.cess)}</strong></span>
                )}
                {/* v1.10.74 - hide when there is nothing to round, like View/PDF. */}
                {form.applyRoundOff && Math.abs(formTotals.roundOff) > 0.005 && (
                  <span style={{ color: '#475569' }}>
                    Round-off: <strong>{(formTotals.roundOff >= 0 ? '+' : '') + formatCurrency(formTotals.roundOff)}</strong>
                  </span>
                )}
                <span>Total: <strong>{formatCurrency(formTotals.finalTotal)}</strong></span>
              </div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', fontSize: '0.78rem', cursor: 'pointer', marginTop: '0.6rem', color: '#475569' }}>
                <input type="checkbox" checked={!!form.applyRoundOff}
                  onChange={e => updateField('applyRoundOff', e.target.checked)}
                  style={{ width: 14, height: 14, accentColor: 'var(--primary)' }} />
                <span>
                  <strong>Apply round-off</strong> — round the grand total to the nearest rupee.
                  Use when the supplier's bill is rounded (e.g. ₹1,234.56 → ₹1,235). Off by default —
                  most suppliers' totals already match what's calculated from line items.
                </span>
              </label>
            </div>

            <div className="flex gap-2 justify-end mt-4">
              <button className="btn btn-secondary" onClick={closeForm}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSave}><Save size={16} /> {editingId ? 'Update' : 'Save'}</button>
            </div>
          </div>
        </div>
      )}

      {/* Purchase Table */}
      <div className="glass-panel">
        <div className="table-header" style={{ flexWrap: 'wrap', gap: '0.5rem' }}>
          <h3>Purchase Records</h3>
          <TableExport title="Purchase register" filename="Purchases" landscape
            subtitle={ownerProfile?.businessName || ''}
            headers={['Date', 'Supplier', 'GSTIN', 'Invoice No', 'Taxable Amount', 'Tax (excl. cess)', 'Cess', 'Inter-state', 'Round-off', 'Total', 'Status', 'Note']}
            rows={registerRows} />
        </div>
        {filtered.length === 0 ? (
          <div className="empty-state">
            <ShoppingCart size={48} />
            <p>{purchases.length === 0 ? 'No purchase bills recorded yet.' : 'No purchases match your filters.'}</p>
            {purchases.length === 0 && <button className="btn btn-primary" onClick={openAdd}><Plus size={18} /> Add Purchase</button>}
          </div>
        ) : (
          <div className="table-scroll">
            <table className="data-table" style={{ minWidth: '800px' }}>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Supplier</th>
                  <th>GSTIN</th>
                  <th>Invoice No</th>
                  <th style={{ textAlign: 'right' }}>Taxable</th>
                  <th style={{ textAlign: 'right' }}>Tax</th>
                  <th style={{ textAlign: 'right' }}>Total</th>
                  <th>Status</th>
                  <th className="col-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(p => {
                  const t = calcPurchaseTotal(p.items, !!p.applyRoundOff);
                  return (
                    <tr key={p.id}>
                      <td className="text-muted">{p.date ? new Date(p.date).toLocaleDateString('en-IN') : ''}</td>
                      <td className="font-medium">{p.supplierName}</td>
                      <td className="text-muted" style={{ fontSize: '0.78rem' }}>{p.supplierGstin || '-'}</td>
                      <td><span className="invoice-badge">{p.invoiceNumber}</span></td>
                      <td style={{ textAlign: 'right' }}>{formatCurrency(t.taxable)}</td>
                      <td style={{ textAlign: 'right' }} className="text-muted">{formatCurrency(t.tax)}</td>
                      <td style={{ textAlign: 'right' }} className="font-bold">{formatCurrency(t.finalTotal)}</td>
                      {/* v1.10.69 - requested (#71 item 3, @sangwanmail-eng):
                          "the Status column should have a drop-down option,
                          similar to the Status drop-down available on the
                          Dashboard." Marking a supplier bill paid took
                          opening it, changing one field and saving. */}
                      <td>
                        <select className="status-select"
                          value={p.paymentStatus || 'Unpaid'}
                          style={{ background: PAYMENT_STATUS_COLORS[p.paymentStatus || 'Unpaid'].bg, color: PAYMENT_STATUS_COLORS[p.paymentStatus || 'Unpaid'].color, borderColor: PAYMENT_STATUS_COLORS[p.paymentStatus || 'Unpaid'].color + '44' }}
                          onChange={e => changePaymentStatus(p, e.target.value)}>
                          {PAYMENT_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </td>
                      <td>
                        <div className="table-actions">
                          {/* v1.10.30 — quick View modal (no download).
                              Modal has a Download PDF button inside for
                              users who do want the file. */}
                          <button className="icon-btn" onClick={() => setViewPurchase(p)} title="View details (no download)"><Eye size={15} /></button>
                          <button className="icon-btn icon-btn-blue" onClick={() => openEdit(p)} title="Edit"><Edit3 size={15} /></button>
                          <button className="icon-btn icon-btn-red" onClick={() => handleDelete(p.id)} title="Delete"><Trash2 size={15} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr style={{ fontWeight: 'bold', borderTop: '2px solid var(--border)' }}>
                  <td colSpan={4}>Total</td>
                  <td style={{ textAlign: 'right' }}>{formatCurrency(totalStats.taxable)}</td>
                  <td style={{ textAlign: 'right' }}>{formatCurrency(totalStats.tax)}</td>
                  <td style={{ textAlign: 'right' }}>{formatCurrency(totalStats.total)}</td>
                  <td colSpan={2}></td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
